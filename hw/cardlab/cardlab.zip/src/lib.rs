#![doc = include_str!("../README.md")]

mod card;
pub use card::Card;

#[cfg(test)]
mod tests;
