/// Make me compile!
/// Hint: Run `cargo test` and see what the compiler tells you! Are you missing any keywords?

#[test]
fn let_x_be() {
    x = 5;
    println!("x has the value {}", x);
}
