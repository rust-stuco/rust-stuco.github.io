//! All examples taken from
//! [rustlings exercises](https://github.com/rust-lang/rustlings/tree/main/exercises/move_semantics)
//! and [practice.rs](https://practice.rs/ownership/ownership.html)
//!
//! Uncomment each of these and ensure that it compiles with `cargo test`.
//! We recommend uncommenting them one at a time.
//! Make sure you read ALL of the error messages! They contain VERY useful information.

// pub mod move_semantics1;
// pub mod move_semantics2;
// pub mod move_semantics3;
// pub mod move_semantics4;
// pub mod move_semantics5;
