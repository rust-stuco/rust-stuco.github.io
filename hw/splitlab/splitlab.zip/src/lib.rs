#![doc = include_str!("../README.md")]

pub mod split_pattern;
pub mod split_str;

#[cfg(test)]
mod tests;
