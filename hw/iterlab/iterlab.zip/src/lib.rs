#![doc = include_str!("../README.md")]

pub mod hofs;
pub mod iterators;

#[cfg(test)]
pub mod tests;
