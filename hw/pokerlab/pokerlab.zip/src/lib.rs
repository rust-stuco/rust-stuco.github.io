#![doc = include_str!("../README.md")]

pub mod card;
pub mod hand;
