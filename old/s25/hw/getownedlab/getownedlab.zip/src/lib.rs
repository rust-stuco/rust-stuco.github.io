#![doc = include_str!("../README.md")]

pub mod move_semantics;
pub mod slices;
pub mod strings;
