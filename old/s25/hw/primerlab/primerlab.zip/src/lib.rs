#![doc = include_str!("../README.md")]

pub mod exercises;
pub mod functions;

#[cfg(test)]
pub mod tests;
