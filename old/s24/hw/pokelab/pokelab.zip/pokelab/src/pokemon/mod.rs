pub mod charmander;
pub mod eevee;

#[cfg(test)]
mod tests;
