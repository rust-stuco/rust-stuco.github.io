pub mod email_reader;
pub mod tweet_reader;

#[cfg(test)]
pub mod tests;
