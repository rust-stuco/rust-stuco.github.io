//! All examples taken from [practice.rs](https://practice.rs/compound-types/slice.html)
//!
//! Uncomment each of these and ensure that it compiles with `cargo test`.
//! We recommend uncommenting them one at a time.
//! Make sure you read ALL of the error messages! They contain VERY useful information.

pub mod slices1;
// pub mod slices2;
// pub mod slices3;
